# Variable Factor Map

## 1) Description
The package provides a convinient way for Python users to plot the Variable Factor Map.

# 2) Requirement
Python 3.6